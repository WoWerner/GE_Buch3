UPDATE personen SET vorname = replace(vorname, 'ÃŸ', 'ß');
UPDATE personen SET vorname = replace(vorname, 'Ã¤', 'ä');
UPDATE personen SET vorname = replace(vorname, 'Ã¼', 'ü');
UPDATE personen SET vorname = replace(vorname, 'Ã¶', 'ö');
UPDATE personen SET vorname = replace(vorname, 'Ã„', 'Ä');
UPDATE personen SET vorname = replace(vorname, 'Ãœ', 'Ü');
UPDATE personen SET vorname = replace(vorname, 'Ã–', 'Ö');
UPDATE personen SET vorname = replace(vorname, 'â‚¬', '€');

UPDATE personen SET Nachname = replace(Nachname, 'ÃŸ', 'ß');
UPDATE personen SET Nachname = replace(Nachname, 'Ã¤', 'ä');
UPDATE personen SET Nachname = replace(Nachname, 'Ã¼', 'ü');
UPDATE personen SET Nachname = replace(Nachname, 'Ã¶', 'ö');
UPDATE personen SET Nachname = replace(Nachname, 'Ã„', 'Ä');
UPDATE personen SET Nachname = replace(Nachname, 'Ãœ', 'Ü');
UPDATE personen SET Nachname = replace(Nachname, 'Ã–', 'Ö');
UPDATE personen SET Nachname = replace(Nachname, 'â‚¬', '€');

UPDATE personen SET Strasse = replace(Strasse, 'ÃŸ', 'ß');
UPDATE personen SET Strasse = replace(Strasse, 'Ã¤', 'ä');
UPDATE personen SET Strasse = replace(Strasse, 'Ã¼', 'ü');
UPDATE personen SET Strasse = replace(Strasse, 'Ã¶', 'ö');
UPDATE personen SET Strasse = replace(Strasse, 'Ã„', 'Ä');
UPDATE personen SET Strasse = replace(Strasse, 'Ãœ', 'Ü');
UPDATE personen SET Strasse = replace(Strasse, 'Ã–', 'Ö');
UPDATE personen SET Strasse = replace(Strasse, 'â‚¬', '€');

UPDATE personen SET Ort = replace(Ort, 'ÃŸ', 'ß');
UPDATE personen SET Ort = replace(Ort, 'Ã¤', 'ä');
UPDATE personen SET Ort = replace(Ort, 'Ã¼', 'ü');
UPDATE personen SET Ort = replace(Ort, 'Ã¶', 'ö');
UPDATE personen SET Ort = replace(Ort, 'Ã„', 'Ä');
UPDATE personen SET Ort = replace(Ort, 'Ãœ', 'Ü');
UPDATE personen SET Ort = replace(Ort, 'Ã–', 'Ö');
UPDATE personen SET Ort = replace(Ort, 'â‚¬', '€');

UPDATE personen SET Ortsteil = replace(Ortsteil, 'ÃŸ', 'ß');
UPDATE personen SET Ortsteil = replace(Ortsteil, 'Ã¤', 'ä');
UPDATE personen SET Ortsteil = replace(Ortsteil, 'Ã¼', 'ü');
UPDATE personen SET Ortsteil = replace(Ortsteil, 'Ã¶', 'ö');
UPDATE personen SET Ortsteil = replace(Ortsteil, 'Ã„', 'Ä');
UPDATE personen SET Ortsteil = replace(Ortsteil, 'Ãœ', 'Ü');
UPDATE personen SET Ortsteil = replace(Ortsteil, 'Ã–', 'Ö');
UPDATE personen SET Ortsteil = replace(Ortsteil, 'â‚¬', '€');

UPDATE Journal SET Buchungstext = replace(Buchungstext, 'ÃŸ', 'ß');
UPDATE Journal SET Buchungstext = replace(Buchungstext, 'Ã¤', 'ä');
UPDATE Journal SET Buchungstext = replace(Buchungstext, 'Ã¼', 'ü');
UPDATE Journal SET Buchungstext = replace(Buchungstext, 'Ã¶', 'ö');
UPDATE Journal SET Buchungstext = replace(Buchungstext, 'Ã„', 'Ä');
UPDATE Journal SET Buchungstext = replace(Buchungstext, 'Ãœ', 'Ü');
UPDATE Journal SET Buchungstext = replace(Buchungstext, 'Ã–', 'Ö');
UPDATE Journal SET Buchungstext = replace(Buchungstext, 'â‚¬', '€');

UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'ÃŸ', 'ß');
UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'Ã¤', 'ä');
UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'Ã¼', 'ü');
UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'Ã¶', 'ö');
UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'Ã„', 'Ä');
UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'Ãœ', 'Ü');
UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'Ã–', 'Ö');
UPDATE Sachkonten SET Sachkonto = replace(Sachkonto, 'â‚¬', '€');

              
select * from konten 
where (konten.Kontotype <> "B")
order by SortPos